# Coin face artwork

Seven designs from Norse_Brainstorm.html, Props & specs → The hoard and treasure tally.

- `*.svg`: closed vector profiles, black shapes only, suitable for extrusion.
- `*.png`: 2000 × 2000 pure black-and-white previews, matching the vectors.
- `Coin_Faces_Overview.png`: labelled contact sheet; do not use as a relief mask.
- `sources/`: original ImageGen outputs, retained for rebuilding.

Import an SVG into your modelling software. Scale it to your chosen size, then extrude
the black shapes and union them with a solid circular coin blank. The white/transparent
areas are empty space in the artwork, not holes through the finished coin. Preserve
the empty counters inside rings and letters. No background rectangle is included.

The SVG canvas is 1000 × 1000 units; artwork fits within radius 460 around (500,500).
Use the canvas as the intended coin diameter, or fit imported artwork within 92% of
the blank's diameter. Physical diameter, blank thickness, relief height, reverse face,
printer type and minimum printable feature size have not been specified. These are
art profiles, not STL models or verified ready-to-slice coins. Inspect narrow gaps and
pointed tips at final scale and test one coin before printing the set.

Packing implied by the current page: 4 common + 1 rare dirham; 3 common + 1 rare denier;
1 Hedeby, 1 York and 1 raven. The Viking game values remain 5, 100 and 3600. Values are
not engraved into the artwork. Decoy exchange rates and the merchant's key are still open.

The geometric pseudo-script is decorative, not readable Arabic or a historical inscription.
The designs are simplified game props, not historical replicas.

Built with the built-in ImageGen tool, then traced at luminance 128 into closed polygon
profiles (0.7 source-pixel contour tolerance; specks below 24 and counters below 160
source-pixel area removed). SVG loops have opposite winding for holes, use solid fills, and contain
no strokes, fonts, raster images or external dependencies. Original prompts and correction
prompts are in generation_manifest.json and the main brainstorming HTML.

Rebuild: `python build_coin_art.py` (Pillow, numpy, opencv-python-headless, shapely).
